//#include "stdafx.h"

#include<string.h>
#include<stdio.h>
#include<GL/glut.h>
//#include <stdlib.h>
#define SPEED 30.0
int entry, l, sit = 0, Effect = 0, go = 0, g1 = 0, z = 0, ze = 0, zc = 0, w = 0, zx = 0, zy = 0, xx = 0, yy = 0, xy = 0;
float i = 0.0, m = 0.0, n = 0.0, o = 0.0, c = 0.0, b = 0.0;
float p = 0.75, q = 0.47, r = 0.14;
float e = 0.0, f = 0.0, g = 0.0;
int count = 0, cough = 0, walking = 0, shake = 0, s = 0, end = 0;
int u, k = 0, stage1;
int light = 1, day = 1, plane = 0, comet = 0, xm = 900, bird = 0, ex;
char ch;

void declare(char *string)
{
	while (*string)
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *string++);
}

void draw_pixel(GLint cx, GLint cy)
{

	glBegin(GL_POINTS);
	glVertex2i(cx, cy);
	glEnd();
}

void plotpixels(GLint h, GLint k, GLint x, GLint y)
{
	draw_pixel(x + h, y + k);
	draw_pixel(-x + h, y + k);
	draw_pixel(x + h, -y + k);
	draw_pixel(-x + h, -y + k);
	draw_pixel(y + h, x + k);
	draw_pixel(-y + h, x + k);
	draw_pixel(y + h, -x + k);
	draw_pixel(-y + h, -x + k);
}


void draw_circle(GLint h, GLint k, GLint r)
{
	glPointSize(3);
	GLint d = 1 - r, x = 0, y = r;
	while (y>x)
	{
		plotpixels(h, k, x, y);
		if (d<0) d += 2 * x + 3;
		else
		{
			d += 2 * (x - y) + 5;
			--y;
		}
		++x;
	}
	plotpixels(h, k, x, y);
}

void print(char s[], float x, float y)
{
	glRasterPos2f(x, y);

	int len = (int)strlen(s);
	glColor3f(0.2, 0, 0);

	for (int i = 0; i < len; i++)

	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);

	}
}

void stickman()
{
	//head
	for (int l = 0; l <= 11; l++)
	{
		glColor3f(0, 0, 0);
		draw_circle(-20 + k, 170, l);
	}
	//body
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(-20 + k, 155);
	glVertex2f(-20 + k, 125);
	glEnd();

	//left leg
	glBegin(GL_LINES);
	glVertex2f(-20 + k, 125);
	glVertex2f(-35 + k, 95);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(-20 + k, 125);
	glVertex2f(-5 + k, 95);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(-20 + k, 155);
	glVertex2f(-35 + k, 125);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(-20 + k, 155);
	glVertex2f(-5 + k, 125);
	glEnd();

	//banner
	glBegin(GL_POLYGON);
	glColor3f(1, 1, 1);
	glVertex2f(700, 150);
	glVertex2f(700, 200);
	glVertex2f(750, 200);
	glVertex2f(750, 150);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1, 1, 1);
	glVertex2f(700, 150);
	glVertex2f(700, 160);
	glVertex2f(650, 135);
	glEnd();
	glColor3f(0, 0, 0);
	print("jai!", 720, 170);
	//banner
	glBegin(GL_POLYGON);
	glColor3f(1, 1, 1);
	glVertex2f(250, 100);
	glVertex2f(300, 100);
	glVertex2f(300, 150);
	glVertex2f(250, 150);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1, 1, 1);
	glVertex2f(300, 100);
	glVertex2f(300, 110);
	glVertex2f(340, 90);
	glEnd();
	glColor3f(0, 0, 0);
	print("jai!", 260, 120);

}

void stickman1()
{
	//head
	for (int l = 0; l <= 11; l++)
	{
		glColor3f(0, 0, 0);
		draw_circle(1150 - k, 110, l);
	}
	//body
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(1150 - k, 95);
	glVertex2f(1150 - k, 45);
	glEnd();

	//left leg
	glBegin(GL_LINES);
	glVertex2f(1150 - k, 45);
	glVertex2f(1135 - k, 15);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(1150 - k, 45);
	glVertex2f(1165 - k, 15);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(1150 - k, 95);
	glVertex2f(1135 - k, 65);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(1150 - k, 95);
	glVertex2f(1165 - k, 65);
	glEnd();
}

void stickman2()
{
	//head
	for (int l = 0; l <= 11; l++)
	{
		glColor3f(1, 0, 0);
		draw_circle(650 + g1, 170, l);
	}
	//body
	glColor3f(1, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(650 + g1, 155);
	glVertex2f(650 + g1, 125);
	glEnd();

	//left leg
	glBegin(GL_LINES);
	glVertex2f(650 + g1, 125);
	glVertex2f(635 + g1, 95);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(650 + g1, 125);
	glVertex2f(665 + g1, 95);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(650 + g1, 155);
	glVertex2f(635 + g1, 125);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(650 + g1, 155);
	glVertex2f(665 + g1, 125);
	glEnd();
}

void stickman3()
{
	//head
	for (int l = 0; l <= 11; l++)
	{
		glColor3f(0, 0, 0);
		draw_circle(300 - g1, 110, l);
	}
	//body
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(300 - g1, 95);
	glVertex2f(300 - g1, 45);
	glEnd();

	//left leg
	glBegin(GL_LINES);
	glVertex2f(300 - g1, 45);
	glVertex2f(285 - g1, 15);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(300 - g1, 45);
	glVertex2f(315 - g1, 15);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(300 - g1, 95);
	glVertex2f(285 - g1, 65);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(300 - g1, 95);
	glVertex2f(315 - g1, 65);
	glEnd();
}
void stickman4()
{

	//body
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(400, 255);
	glVertex2f(400, 125);
	glEnd();
	//head
	for (int l = 0; l <= 31; l++)
	{
		glPointSize(5);
		glColor3f(1, 0, 0);
		draw_circle(400, 270, l);
	}
	glColor3f(0, 0, 0);
	//left leg
	glBegin(GL_LINES);
	glVertex2f(400, 125);
	glVertex2f(375, 75);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(400, 125);
	glVertex2f(425, 75);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(400, 220);
	glVertex2f(375, 170);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(400, 220);
	glVertex2f(420, 200);
	glEnd();
	if (cough == 0)
		glColor3f(1, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(420, 200);
	glVertex2f(460 - zc + zx - xx, 160 + ze - zy + yy);
	glEnd();
	if (walking == 0 && cough == 1)
	{
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(450, 280);
		glVertex2f(450, 310);
		glVertex2f(520, 310);
		glVertex2f(520, 280);
		glEnd();
		glColor3f(0, 0, 0);
		print("aaa-chew", 460, 290);
	}
}

void stickman5()
{
	//head
	for (int l = 0; l <= 31; l++)
	{
		glColor3f(0, 0, 0);
		draw_circle(-20 + w, 270, l);
	}
	//body
	glColor3f(0, 0, 0);
	glBegin(GL_LINES);
	glVertex2f(-20 + w, 255);
	glVertex2f(-20 + w, 125);
	glEnd();

	//left leg
	glBegin(GL_LINES);
	glVertex2f(-20 + w, 125);
	glVertex2f(-45 + w, 75);
	glEnd();

	//right leg
	glBegin(GL_LINES);
	glVertex2f(-20 + w, 125);
	glVertex2f(5 + w, 75);
	glEnd();

	//left hand
	glBegin(GL_LINES);
	glVertex2f(-20 + w, 220);
	glVertex2f(-45 + w, 170);
	glEnd();

	//right hand
	glBegin(GL_LINES);
	glVertex2f(-20 + w, 220);
	glVertex2f(5 + w + xy, 170 + yy);
	glEnd();
	if (shake == 1)
	{
		//banner
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(170, 280);
		glVertex2f(170, 310);
		glVertex2f(250, 310);
		glVertex2f(250, 280);
		glEnd();

		glColor3f(0, 0, 0);
		print("hey! John", 180, 290);

		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(450, 280);
		glVertex2f(450, 310);
		glVertex2f(520, 310);
		glVertex2f(520, 280);
		glEnd();
		glColor3f(0, 0, 0);
		print("high five", 460, 290);

	}


}

void effect()
{
	if (Effect == 1)
	{
		//banner
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(770, 500);
		glVertex2f(770, 600);
		glVertex2f(1100, 600);
		glVertex2f(1100, 500);
		glEnd();
		glColor3f(0, 0, 0);
		print("Such community gathering", 800, 560);
		print("is the easiest way", 800, 540);
		print("to spread the virus", 800, 520);

		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(350, 100);
		glVertex2f(350, 120);
		glVertex2f(350, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 100);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(420, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(400, 100);
		glVertex2f(400, 120);
		glVertex2f(400, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 100);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(470, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(450, 100);
		glVertex2f(450, 120);
		glVertex2f(450, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 100);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(520, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(500, 100);
		glVertex2f(500, 120);
		glVertex2f(500, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 100);
		glEnd();

		//person5
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(570, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(550, 100);
		glVertex2f(550, 120);
		glVertex2f(550, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 100);
		glEnd();

		//person6
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(620, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(600, 100);
		glVertex2f(600, 120);
		glVertex2f(600, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 100);
		glEnd();

		//row2
		//person1
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(350, 50);
		glVertex2f(350, 70);
		glVertex2f(350, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 50);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(420, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(400, 50);
		glVertex2f(400, 70);
		glVertex2f(400, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 50);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(470, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(450, 50);
		glVertex2f(450, 70);
		glVertex2f(450, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 50);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(520, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(500, 50);
		glVertex2f(500, 70);
		glVertex2f(500, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 50);
		glEnd();

		//person5
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(570, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(550, 50);
		glVertex2f(550, 70);
		glVertex2f(550, 70);
		glVertex2f(590, 70);
		glVertex2f(590, 70);
		glVertex2f(590, 50);
		glEnd();

		//person6
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(620, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(600, 50);
		glVertex2f(600, 70);
		glVertex2f(600, 70);
		glVertex2f(640, 70);
		glVertex2f(640, 70);
		glVertex2f(640, 50);
		glEnd();

	}
}
void Go()
{
	if (go == 1)
	{
		//banner
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(800, 200);
		glVertex2f(800, 280);
		glVertex2f(1000, 280);
		glVertex2f(1000, 200);
		glEnd();

		glColor3f(0, 0, 0);
		print("The man is the", 820, 260);
		print("potential carrier", 820, 240);
		print("of the virus", 820, 220);
		//person1
		Effect = 0;
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(350, 100);
		glVertex2f(350, 120);
		glVertex2f(350, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 100);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(420, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(400, 100);
		glVertex2f(400, 120);
		glVertex2f(400, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 100);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(470, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(450, 100);
		glVertex2f(450, 120);
		glVertex2f(450, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 100);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(520, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(500, 100);
		glVertex2f(500, 120);
		glVertex2f(500, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 100);
		glEnd();

		//person5
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(570, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(550, 100);
		glVertex2f(550, 120);
		glVertex2f(550, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 100);
		glEnd();

		//person6
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(620, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(600, 100);
		glVertex2f(600, 120);
		glVertex2f(600, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 100);
		glEnd();

		//row2
		//person1
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(350, 50);
		glVertex2f(350, 70);
		glVertex2f(350, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 50);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(420, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(400, 50);
		glVertex2f(400, 70);
		glVertex2f(400, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 50);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(470, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(450, 50);
		glVertex2f(450, 70);
		glVertex2f(450, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 50);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(520, 85, l);
		}
		glBegin(GL_LINES);
		glVertex2f(500, 50);
		glVertex2f(500, 70);
		glVertex2f(500, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 50);
		glEnd();

		stickman3();
		stickman2();
	}


}
void stage()
{
	if (stage1 == 1)
	{
		//stage
		//glClear(GL_COLOR_BUFFER_BIT);
		glColor3f(0.5, 0.35, 0.05);
		glBegin(GL_POLYGON);
		glVertex2f(350, 200);
		glVertex2f(400, 270);
		glVertex2f(600, 270);
		glVertex2f(650, 200);
		glEnd();

		glColor3f(0.5, 0.25, 0.05);
		glBegin(GL_POLYGON);
		glVertex2f(350, 200);
		glVertex2f(350, 150);
		glVertex2f(650, 150);
		glVertex2f(650, 200);
		glEnd();

		//head
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(500, 300, l);
		}

		glLineWidth(3);

		//body
		glColor3f(0, 0, 0);
		glBegin(GL_LINES);
		glVertex2f(500, 240);
		glVertex2f(500, 300);
		glEnd();

		//left leg
		glBegin(GL_LINES);
		glVertex2f(500, 240);
		glVertex2f(485, 220);
		glEnd();

		//right leg
		glBegin(GL_LINES);
		glVertex2f(500, 240);
		glVertex2f(515, 220);
		glEnd();

		//left hand
		glBegin(GL_LINES);
		glVertex2f(500, 290);
		glVertex2f(485, 270);
		glEnd();

		//right hand
		glBegin(GL_LINES);
		glVertex2f(500, 290);
		glVertex2f(515, 270);
		glEnd();

		//mic
		glBegin(GL_LINES);
		glLineWidth(0.5);
		glVertex2f(540, 210);
		glVertex2f(540, 300);
		glEnd();
		glBegin(GL_LINES);
		glVertex2f(540, 300);
		glVertex2f(520, 295);
		glEnd();
		for (int l = 0; l <= 5; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(520, 297, l);
		}
		//row
		//person1
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(350, 100);
		glVertex2f(350, 120);
		glVertex2f(350, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 120);
		glVertex2f(390, 100);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(1, 0, 0);
			draw_circle(420, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(400, 100);
		glVertex2f(400, 120);
		glVertex2f(400, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 120);
		glVertex2f(440, 100);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(470, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(450, 100);
		glVertex2f(450, 120);
		glVertex2f(450, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 120);
		glVertex2f(490, 100);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(520, 135, l);
		}
		glBegin(GL_LINES);
		glVertex2f(500, 100);
		glVertex2f(500, 120);
		glVertex2f(500, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 120);
		glVertex2f(540, 100);
		glEnd();

		//person5
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(570, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(550, 100);
		glVertex2f(550, 120);
		glVertex2f(550, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 120);
		glVertex2f(590, 100);
		glEnd();

		//person6
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(620, 135, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(600, 100);
		glVertex2f(600, 120);
		glVertex2f(600, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 120);
		glVertex2f(640, 100);
		glEnd();

		//row2
		//person1
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(370, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(350, 50);
		glVertex2f(350, 70);
		glVertex2f(350, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 70);
		glVertex2f(390, 50);
		glEnd();

		//person2
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(420, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(400, 50);
		glVertex2f(400, 70);
		glVertex2f(400, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 70);
		glVertex2f(440, 50);
		glEnd();

		//person3
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(470, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(450, 50);
		glVertex2f(450, 70);
		glVertex2f(450, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 70);
		glVertex2f(490, 50);
		glEnd();

		//person4
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(520, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(500, 50);
		glVertex2f(500, 70);
		glVertex2f(500, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 70);
		glVertex2f(540, 50);
		glEnd();

		//person5
		for (int l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(570, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(550, 50);
		glVertex2f(550, 70);
		glVertex2f(550, 70);
		glVertex2f(590, 70);
		glVertex2f(590, 70);
		glVertex2f(590, 50);
		glEnd();

		//person6
		for (l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(620, 85, l);
		}
		glBegin(GL_LINES);
		glColor3f(0, 0, 0);
		glVertex2f(600, 50);
		glVertex2f(600, 70);
		glVertex2f(600, 70);
		glVertex2f(640, 70);
		glVertex2f(640, 70);
		glVertex2f(640, 50);
		glEnd();

		//banner
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(570, 300);
		glVertex2f(570, 390);
		glVertex2f(760, 390);
		glVertex2f(760, 300);
		glEnd();
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(570, 300);
		glVertex2f(570, 320);
		glVertex2f(540, 290);
		glEnd();
		glColor3f(0, 0, 0);
		print("Welcome all!", 600, 360);
		print("today we have", 600, 340);
		print("gathered for....", 600, 320);

		//icecream parlor
		//top surface
		glColor3f(1, 0.45, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(970, 220);
		glVertex2i(990, 220);
		glVertex2i(990, 100);
		glVertex2i(970, 100);
		glEnd();
		glColor3f(0.8, 0.8, 0);
		glBegin(GL_POLYGON);
		glVertex2i(990, 220);
		glVertex2i(1010, 220);
		glVertex2i(1010, 100);
		glVertex2i(990, 100);
		glEnd();

		//ice-cream man
		for (l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(1020, 250, l);
		}
		glColor3f(0, 0, 0);
		glBegin(GL_LINES);
		glVertex2f(1020, 210);
		glVertex2f(1020, 250);
		glEnd();
		//left hand
		glBegin(GL_LINES);
		glVertex2f(1020, 240);
		glVertex2f(1000, 220);
		glEnd();

		//right hand
		glBegin(GL_LINES);
		glVertex2f(1020, 240);
		glVertex2f(1035, 220);
		glEnd();

		glColor3f(1, 0.45, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(1010, 220);
		glVertex2i(1030, 220);
		glVertex2i(1030, 100);
		glVertex2i(1010, 100);
		glEnd();
		glColor3f(0.8, 0.8, 0);
		glBegin(GL_POLYGON);
		glVertex2i(1030, 220);
		glVertex2i(1050, 220);
		glVertex2i(1050, 100);
		glVertex2i(1030, 100);
		glEnd();

		glColor3f(1, 0.45, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(1050, 220);
		glVertex2i(1070, 220);
		glVertex2i(1070, 100);
		glVertex2i(1050, 100);
		glEnd();



		glBegin(GL_LINES);
		glVertex2i(1068, 220);
		glVertex2i(1068, 300);
		glEnd();

		glBegin(GL_LINES);
		glVertex2i(972, 220);
		glVertex2i(972, 300);
		glEnd();

		glBegin(GL_LINES);
		glVertex2i(972, 300);
		glVertex2i(1020, 400);
		glEnd();
		glBegin(GL_LINES);
		glVertex2i(1020, 400);
		glVertex2i(1070, 300);
		glEnd();
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(985, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(1008, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(1031, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(1054, 300, l);
		}

		glColor3f(1, 0.45, 0.5);
		glLineWidth(7.0);
		glBegin(GL_POLYGON);
		glVertex2i(970, 300);
		glVertex2i(1020, 400);
		glVertex2i(1070, 300);
		glEnd();
		glColor3f(0.2, 0, 1);
		print("Baskin", 1003, 200);
		glColor3f(0.2, 0, 1);
		print("Robbins", 1000, 180);
		glColor3f(0.2, 0, 1);
		print("Ice-Cream", 995, 160);
		glPushMatrix();
		glTranslated(0, 20, 0);
		glRotatef(-80, 1, 0.5, 0.8);
		glRotatef(0, 0, 0, 1);
		glScalef(1.5, 1.5, 0.1);
		glutSolidCube(50);
		glPopMatrix();

		//popcorn stand
		glColor3f(0, 1, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(850, 220);
		glVertex2i(870, 220);
		glVertex2i(870, 100);
		glVertex2i(850, 100);
		glEnd();
		glColor3f(1, 1, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(870, 220);
		glVertex2i(890, 220);
		glVertex2i(890, 100);
		glVertex2i(870, 100);
		glEnd();

		//ice-cream man
		for (l = 0; l <= 11; l++)
		{
			glColor3f(0, 0, 0);
			draw_circle(900, 250, l);
		}
		glColor3f(0, 0, 0);
		glBegin(GL_LINES);
		glVertex2f(900, 210);
		glVertex2f(900, 250);
		glEnd();
		//left hand
		glBegin(GL_LINES);
		glVertex2f(900, 240);
		glVertex2f(880, 220);
		glEnd();

		//right hand
		glBegin(GL_LINES);
		glVertex2f(900, 240);
		glVertex2f(915, 220);
		glEnd();

		glColor3f(0, 1, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(890, 220);
		glVertex2i(910, 220);
		glVertex2i(910, 100);
		glVertex2i(890, 100);
		glEnd();
		glColor3f(1, 1, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(910, 220);
		glVertex2i(930, 220);
		glVertex2i(930, 100);
		glVertex2i(910, 100);
		glEnd();

		glColor3f(0, 1, 0.5);
		glBegin(GL_POLYGON);
		glVertex2i(930, 220);
		glVertex2i(950, 220);
		glVertex2i(950, 100);
		glVertex2i(930, 100);
		glEnd();



		glBegin(GL_LINES);
		glVertex2i(948, 220);
		glVertex2i(948, 300);
		glEnd();

		glBegin(GL_LINES);
		glVertex2i(852, 220);
		glVertex2i(852, 300);
		glEnd();

		glBegin(GL_LINES);
		glVertex2i(852, 300);
		glVertex2i(900, 400);
		glEnd();
		glBegin(GL_LINES);
		glVertex2i(900, 400);
		glVertex2i(950, 300);
		glEnd();
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(865, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(888, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(911, 300, l);
		}
		for (l = 0; l<11; l++)
		{
			glColor3f(0.81, 0.947, 0.587);
			draw_circle(934, 300, l);
		}

		glColor3f(0, 1, 0.5);
		glLineWidth(7.0);
		glBegin(GL_POLYGON);
		glVertex2i(850, 300);
		glVertex2i(900, 400);
		glVertex2i(950, 300);
		glEnd();
		glColor3f(0.2, 0, 1);
		print("Tasty", 883, 200);
		glColor3f(0.2, 0, 1);
		print("Pop Corn", 865, 180);
		glColor3f(0.2, 0, 1);
		print("Stand", 880, 160);
		glPushMatrix();
		glTranslated(0, 20, 0);
		glRotatef(-80, 1, 0.5, 0.8);
		glRotatef(0, 0, 0, 1);
		glScalef(1.5, 1.5, 0.1);
		glutSolidCube(50);
		glPopMatrix();
		//end of popcorn stand

		if (sit == 1)
		{

			//row3
			//person1
			for (int l = 0; l <= 11; l++)
			{
				glColor3f(0, 0, 0);
				draw_circle(370, 35, l);
			}
			glBegin(GL_LINES);
			glVertex2f(350, 0);
			glVertex2f(350, 20);
			glVertex2f(350, 20);
			glVertex2f(390, 20);
			glVertex2f(390, 20);
			glVertex2f(390, 0);
			glEnd();

			//person2
			for (int l = 0; l <= 11; l++)
			{
				glColor3f(0, 0, 0);
				draw_circle(620, 35, l);
			}
			glBegin(GL_LINES);
			glVertex2f(600, 0);
			glVertex2f(600, 20);
			glVertex2f(600, 20);
			glVertex2f(640, 20);
			glVertex2f(640, 20);
			glVertex2f(640, 0);
			glEnd();
		}

		else
		{
			stickman();
			stickman1();
		}

		effect();
		Go();
	}
	else if (stage1 == 0 && end == 1)
	{
		//banner
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(330, 400);
		glVertex2f(330, 450);
		glVertex2f(680, 450);
		glVertex2f(680, 400);
		glEnd();
		glColor3f(0, 0, 0);
		print("Precautions against spread of COVID-19 VIRUS", 340, 420);

		//1
		glBegin(GL_POLYGON);
		glColor3f(1, 1, 1);
		glVertex2f(330, 160);
		glVertex2f(330, 380);
		glVertex2f(680, 380);
		glVertex2f(680, 160);
		glEnd();
		glColor3f(0, 0, 0);
		print("1.Regularly and thoroughly wash your hands with", 340, 340);
		print("  any soap/ handwash liquid and water", 340, 320);
		print("2.Maintain atleast 2 metre distance from others ", 340, 300);
		print("3.Wear your mask regularly", 340, 280);
		print("4.Stay home, if you feel unwell", 340, 260);
		print("5.Avoid touching your eyes, nose and mouth", 340, 240);
		print("6.Use sanitizers when necessary", 340, 220);
		print("7.Make sure, you and the people around you follow", 340, 200);
		print("  good hygiene", 340, 180);

	}
	else
	{
		//chim

		glColor3f(0.35, 0.0, 0.0);
		glBegin(GL_POLYGON);

		glVertex2f(540, 330);
		glVertex2f(540, 430);
		glVertex2f(960, 430);
		glVertex2f(960, 330);

		glEnd();

		//home

		glColor3f(p, q, r);
		glBegin(GL_POLYGON);

		glVertex2f(550, 100);
		glVertex2f(550, 330);
		glVertex2f(950, 330);
		glVertex2f(950, 100);
		glVertex2f(850, 100);
		glVertex2f(850, 250);
		glVertex2f(650, 250);
		glVertex2f(650, 100);

		glEnd();




		//window border

		glColor3f(0.35, 0.0, 0.0);
		glBegin(GL_POLYGON);

		glVertex2f(595, 205);
		glVertex2f(595, 285);
		glVertex2f(675, 285);
		glVertex2f(675, 205);

		glEnd();


		glBegin(GL_POLYGON);

		glVertex2f(825, 205);
		glVertex2f(825, 285);
		glVertex2f(905, 285);
		glVertex2f(905, 205);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(845, 205);
		glVertex2f(845, 285);
		glVertex2f(850, 285);
		glVertex2f(850, 205);

		glEnd();



		//door
		glColor3f(e, f, g);
		glBegin(GL_POLYGON);

		glVertex2f(800, 100);
		glVertex2f(800, 220);
		glVertex2f(700, 220);
		glVertex2f(700, 100);

		glEnd();

		glColor3f(0.35, 0.0, 0.0);
		glBegin(GL_POLYGON);

		glVertex2f(760, 120);
		glVertex2f(760, 200);
		glVertex2f(700, 220);
		glVertex2f(700, 100);

		glEnd();



		//window
		glColor3f(e, f, g);
		glBegin(GL_POLYGON);

		glVertex2f(600, 210);
		glVertex2f(600, 280);
		glVertex2f(670, 280);
		glVertex2f(670, 210);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(830, 210);
		glVertex2f(830, 280);
		glVertex2f(900, 280);
		glVertex2f(900, 210);

		glEnd();

		glColor3f(0.35, 0.0, 0.0);
		glBegin(GL_POLYGON);

		glVertex2f(620, 210);
		glVertex2f(620, 280);
		glVertex2f(625, 280);
		glVertex2f(625, 210);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(650, 210);
		glVertex2f(650, 280);
		glVertex2f(655, 280);
		glVertex2f(655, 210);

		glEnd();



		glColor3f(0.35, 0.0, 0.0);
		glBegin(GL_POLYGON);

		glVertex2f(850, 205);
		glVertex2f(850, 285);
		glVertex2f(855, 285);
		glVertex2f(855, 205);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(880, 205);
		glVertex2f(880, 285);
		glVertex2f(885, 285);
		glVertex2f(885, 205);

		glEnd();
		stickman4();

		stickman5();
	}


}


void draw_object()
{




	if (day == 1)
	{


		stage();

		//sky
		glColor3f(0.0, 0.9, 0.9);
		glBegin(GL_POLYGON);
		glVertex2f(0, 380);
		glVertex2f(0, 700);
		glVertex2f(1100, 700);
		glVertex2f(1100, 380);
		glEnd();

		//sun
		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 0.9, 0.0);
			draw_circle(100, 625, l);
		}

		//plane
		if (plane == 1)
		{
			glColor3f(1.0, 1.0, 1.0);
			glBegin(GL_POLYGON);
			glVertex2f(925 + n, 625 + o);
			glVertex2f(950 + n, 640 + o);
			glVertex2f(1015 + n, 640 + o);
			glVertex2f(1030 + n, 650 + o);
			glVertex2f(1050 + n, 650 + o);
			glVertex2f(1010 + n, 625 + o);
			glEnd();

			glColor3f(0.8, 0.8, 0.8);
			glBegin(GL_LINE_LOOP);
			glVertex2f(925 + n, 625 + o);
			glVertex2f(950 + n, 640 + o);
			glVertex2f(1015 + n, 640 + o);
			glVertex2f(1030 + n, 650 + o);
			glVertex2f(1050 + n, 650 + o);
			glVertex2f(1010 + n, 625 + o);
			glEnd();
		}

		//cloud1
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}

		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}
		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}

		//grass
		glColor3f(0.6, 0.8, 0.196078);
		glBegin(GL_POLYGON);
		glVertex2f(0, 160);
		glVertex2f(0, 380);
		glVertex2f(1100, 380);
		glVertex2f(1100, 160);
		glEnd();

	}
	else
	{


		//sky
		glColor3f(0.0, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(0, 380);
		glVertex2f(0, 700);
		glVertex2f(1100, 700);
		glVertex2f(1100, 380);
		glEnd();

		//moon
		int l;

		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(100, 625, l);
		}

		//star1
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(575, 653);
		glVertex2f(570, 645);
		glVertex2f(580, 645);
		glVertex2f(575, 642);
		glVertex2f(570, 650);
		glVertex2f(580, 650);
		glEnd();

		//star2
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(975, 643);
		glVertex2f(970, 635);
		glVertex2f(980, 635);
		glVertex2f(975, 632);
		glVertex2f(970, 640);
		glVertex2f(980, 640);
		glEnd();

		//star3
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(875, 543);
		glVertex2f(870, 535);
		glVertex2f(880, 535);
		glVertex2f(875, 532);
		glVertex2f(870, 540);
		glVertex2f(880, 540);
		glEnd();

		//star4
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(375, 598);
		glVertex2f(370, 590);
		glVertex2f(380, 590);
		glVertex2f(375, 587);
		glVertex2f(370, 595);
		glVertex2f(380, 595);
		glEnd();

		//star5
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(750, 628);
		glVertex2f(745, 620);
		glVertex2f(755, 620);
		glVertex2f(750, 618);
		glVertex2f(745, 625);
		glVertex2f(755, 625);
		glEnd();

		//star6
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(200, 628);
		glVertex2f(195, 620);
		glVertex2f(205, 620);
		glVertex2f(200, 618);
		glVertex2f(195, 625);
		glVertex2f(205, 625);
		glEnd();

		//star7
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(100, 528);
		glVertex2f(95, 520);
		glVertex2f(105, 520);
		glVertex2f(100, 518);
		glVertex2f(95, 525);
		glVertex2f(105, 525);
		glEnd();

		//star8
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(300, 468);
		glVertex2f(295, 460);
		glVertex2f(305, 460);
		glVertex2f(300, 458);
		glVertex2f(295, 465);
		glVertex2f(305, 465);
		glEnd();

		//star9
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_TRIANGLES);
		glVertex2f(500, 543);
		glVertex2f(495, 535);
		glVertex2f(505, 535);
		glVertex2f(500, 532);
		glVertex2f(495, 540);
		glVertex2f(505, 540);
		glEnd();


		//comet
		if (comet == 1)
		{
			for (l = 0; l <= 7; l++)
			{
				glColor3f(1.0, 1.0, 1.0);
				draw_circle(300 + c, 675, l);
			}

			glColor3f(1.0, 1.0, 1.0);
			glBegin(GL_TRIANGLES);
			glVertex2f(200 + c, 675);
			glVertex2f(300 + c, 682);
			glVertex2f(300 + c, 668);
			glEnd();
		}

		//Plane
		if (plane == 1)
		{

			for (l = 0; l <= 1; l++)
			{
				glColor3f(1.0, 0.0, 0.0);
				draw_circle(950 + n, 625 + o, l);
				glColor3f(1.0, 1.0, 0.0);
				draw_circle(954 + n, 623 + o, l);

			}



		}

		//grass
		glColor3f(0.0, 0.3, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(0, 160);
		glVertex2f(0, 380);
		glVertex2f(1100, 380);
		glVertex2f(1100, 160);
		glEnd();

	}

	//Ground
	glColor3f(0.0, 0.3, 0.0);
	glBegin(GL_POLYGON);
	glVertex2f(-600, 0);
	glVertex2f(-600, 185);
	glVertex2f(1100, 185);
	glVertex2f(1100, 0);
	glEnd();

	//tree
	glColor3f(0.9, 0.2, 0.0);
	glBegin(GL_POLYGON);
	glVertex2f(280, 185);
	glVertex2f(280, 255);
	glVertex2f(295, 255);
	glVertex2f(295, 185);
	glEnd();


	for (l = 0; l <= 30; l++)
	{
		glColor3f(0.0, 0.5, 0.0);
		draw_circle(270, 250, l);
		draw_circle(310, 250, l);
	}

	for (l = 0; l <= 25; l++)
	{
		glColor3f(0.0, 0.5, 0.0);
		draw_circle(280, 290, l);
		draw_circle(300, 290, l);
	}

	for (l = 0; l <= 20; l++)
	{
		glColor3f(0.0, 0.5, 0.0);
		draw_circle(290, 315, l);
	}


	//tree 1
	glColor3f(0.9, 0.2, 0.0);
	glBegin(GL_POLYGON);
	glVertex2f(100, 135);
	glVertex2f(100, 285);
	glVertex2f(140, 285);
	glVertex2f(140, 135);
	glEnd();


	for (l = 0; l <= 40; l++)
	{
		glColor3f(0.0, 0.5, 0.0);
		draw_circle(40, 280, l);
		draw_circle(90, 280, l);
		draw_circle(150, 280, l);
		draw_circle(210, 280, l);
		draw_circle(65, 340, l);
		draw_circle(115, 340, l);
		draw_circle(175, 340, l);

	}

	for (l = 0; l <= 55; l++)
	{
		glColor3f(0.0, 0.5, 0.0);
		draw_circle(115, 360, l);


	}





	//First Leg 
	glPushMatrix();
	glTranslated(-45, -10, -5);
	glRotatef(45, 0, 1, 0);
	glScalef(0.4, 5.5, 0.4);
	glutSolidCube(10);
	glPopMatrix();

	//Second Leg
	glPushMatrix();
	glTranslated(-10, -25, 5);
	glRotatef(45, 0, 1, 0);
	glScalef(0.4, 4.5, 0.4);
	glutSolidCube(10);
	glPopMatrix();

	//Third Leg 
	glPushMatrix();
	glTranslated(45, -5, -10);
	glRotatef(45, 0, 1, 0);
	glScaled(0.4, 5.5, 0.4);
	glutSolidCube(10);
	glPopMatrix();

	//Fourth Leg
	glPushMatrix();
	glTranslated(10, 5, -35);
	glRotatef(45, 0, 1, 0);
	glScalef(0.4, 6, 0.4);
	glutSolidCube(10);
	glPopMatrix();
	stage();
	glFlush();

	//end of table


	if (bird == 1)
	{


		glColor3f(0.73, 0.16, 0.96);
		glBegin(GL_POLYGON);

		glVertex2f(300 + i - xm, 265 + b);
		glVertex2f(330 + i - xm, 265 + b);
		glVertex2f(330 + i - xm, 250 + b);


		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(330 + i - xm, 275 + b);
		glVertex2f(340 + i - xm, 275 + b);
		glVertex2f(330 + i - xm, 265 + b);


		glEnd();

		//

		glBegin(GL_POLYGON);

		glVertex2f(200 + i - xm, 285 + b);
		glVertex2f(230 + i - xm, 285 + b);
		glVertex2f(230 + i - xm, 270 + b);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(230 + i - xm, 295 + b);
		glVertex2f(240 + i - xm, 295 + b);
		glVertex2f(230 + i - xm, 285 + b);


		glEnd();


		//

		glBegin(GL_POLYGON);

		glVertex2f(150 + i - xm, 285 + b);
		glVertex2f(180 + i - xm, 285 + b);
		glVertex2f(180 + i - xm, 270 + b);

		glEnd();

		glBegin(GL_POLYGON);

		glVertex2f(180 + i - xm, 295 + b);
		glVertex2f(190 + i - xm, 295 + b);
		glVertex2f(180 + i - xm, 285 + b);


		glEnd();


	}



	glFlush();
}


void idle()
{
	if (entry == 1 && (k >= 0 && k <= 350)){
		k += SPEED / 30;
		//rg+=SPEED/30;
	}
	if (go == 1 && g1 >= 0 && g1<600){
		g1 += SPEED / 30;
	}
	if (cough == 1 && (ze >= 0 && ze <= 90) || (zc >= 0 && zc <= 10)){
		ze += SPEED / 30;
		zc += SPEED / 30;
		glBegin(GL_POLYGON);

	}
	if (walking == 1 && (w >= 0 && w <= 300) && ((zx >= 0 && zx <= 80) || (zy >= 0 && zy <= 10))){
		w += SPEED / 7;
		zx += SPEED / 30;
		zy += SPEED / 30;
	}
	if (shake == 1 && (xx >= 0 && xx <= 70) && (yy >= 0 && yy <= 70) && (xy >= 0 && xy <= 70))
	{
		xx += SPEED / 25;
		yy += SPEED / 30;
		xy += SPEED / 30;
	}

	if (light == 0 && (i >= 0 && i <= 1150))
	{

		i += SPEED / 10;
		m += SPEED / 150;
		n -= 2;
		o += 0.2;
		c += 2;

	}

	if (light == 0 && (i >= 2600 && i <= 3000))
	{

		i += SPEED / 10;
		m += SPEED / 150;
		n -= 2;
		o += 0.2;
		c += 2;

	}

	if (light == 0)
	{
		i = i;
		m += SPEED / 150;
		n -= 2;
		o += 0.2;
		c += 2;

	}
	if (count <= 3)
	{

		glClearColor(1.0, 1.0, 1.0, 1.0);

		i += SPEED / 10;
		b += SPEED / 10;
		m += SPEED / 150;
		n -= 2;
		o += 0.2;
		c += 2;
	}
	if (i>1900)
		i = 800.0;
	if (m>1100)
		m = 0.0;
	if (o>75)
	{
		plane = 0;
	}
	if (c>500)
	{
		comet = 0;
	}
	if (b>500)
	{
		b = 0.0;
		i = 800.0;
		count = count + 1;

	}


	glutPostRedisplay();

}


void display()
{

	glClear(GL_COLOR_BUFFER_BIT);
	draw_object();
	glFlush();
}


void keyboardFunc(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 13:
		glClearColor(1.0, 1.0, 1.0, 1.0);

		glutDisplayFunc(display);
		entry = 1;
		stage1 = 1;
		break;
	case 's':
	case 'S':
		sit = 1;
		break;

	case 'd':
	case 'D':
		day = 1;
		p = 0.75;
		q = 0.47;
		r = 0.14;
		break;

	case 'n':
	case 'N':
		day = 0;
		p = 0.52;
		q = 0.37;
		r = 0.26;
		break;

	case 'b':
	case 'B':
		bird = 1;
		i = 800;
		b = 0.0;
		count = 0;
		break;
	case 'e':
	case 'E':
		Effect = 1;
		effect();
		break;

	case 'l':
	case 'L':
		e = 0.90;
		f = 0.91;
		g = 0.98;
		break;
	case 'f':
	case 'F':
		e = 0.0;
		f = 0.0;
		g = 0.0;
		break;
	case 'g':
		go = 1;
		break;
	case 'w':
		walking = 1;
		break;
	case 'h':
		stage1 = 0;
		cough = 1;
		walking = 0;
		break;
	case 'c':
		cough = 0;
		walking = 0;
		break;
	case 'k':
		shake = 1;
		break;
	case 'z':
		end = 1;
		stage1 = 0;
		break;


	}

}


void main_menu(int index)
{
	switch (index)
	{
	case 1:
		if (index == 1)
		{
			plane = 1;
			o = n = 0.0;
		}
		break;

	case 2:
		if (index == 2)
		{
			comet = 1;
			c = 0.5;
		}
		break;
	case 3:
		if (index == 3)
			exit(0);

	}
}
void display_about(void){
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(0.2f,1,1,0.0f);
	//glClearColor(184.0f / 255.0f, 213.0f / 255.0f, 238.0f / 255.0f, 1.0f);
	glRasterPos2f(220, 450);
	//glColor3f(1, 1, 1);
	glColor3f(0.0f, 1.0f, 1.0f);
	char str[] = "Sahyadri College of Engineering and Management";
	glRasterPos2f(384, 950); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str1[] = "Adyar,Mangaluru";
	glRasterPos2f(440.5, 900); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str1); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str1[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str2[] = "Department of Computer Science and Engineering";
	glRasterPos2f(350, 850); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str2); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str2[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str3[] = "COMPUTER GRAPHICS AND VISUALIZATION";
	glRasterPos2f(354, 800); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str3); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str3[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str4[] = "MINI PROJECT";
	glRasterPos2f(435, 700); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str4); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str4[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str5[] = "CG MINI PROJECT ON";
	glRasterPos2f(420, 600); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str5); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str5[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str6[] = " A VISUALIZATION ON SPREAD OF COVID-19 ";
	glRasterPos2f(360, 500); //take midpoint of gluOrtho2D
	for (z = 0; z<strlen(str6); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str6[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str7[] = "Team Members";
	glRasterPos2f(75, 300); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str7); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str7[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str8[] = "MAYOLA ANGELA DSOUZA 4SF18CS081";
	glRasterPos2f(50, 250); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str8); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str8[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str9[] = "ASHIKA K NAIK  4SF18CS019";
	glRasterPos2f(50, 200); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str9); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str9[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str10[] = "Project Guide";
	glRasterPos2f(825, 300); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str10); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str10[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str11[] = " MS SUPRIYA ";
	glRasterPos2f(810, 250); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str11); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str11[z]);
	}
	glColor3f(0.502f, 0.000f, 0.502f);
	char str12[] = " Assisstant Professor         ";
	glRasterPos2f(810, 200); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str12); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str12[z]);
	}
	glColor3f(0.502f, 0.000f, 0.502f);
	char str13[] = " DEPT OF CSE         ";
	glRasterPos2f(810, 150); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str13); z++){
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str13[z]);
	}

	glColor3f(0.502f, 0.000f, 0.502f);
	char str14[] = "Press Enter to go to project";
	glRasterPos2f(430, 50); //calculate points by refering previous text positions
	for (z = 0; z<strlen(str14); z++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str14[z]);
	}
	glBegin(GL_LINES);
	glVertex2f(320, 1000);
	glVertex2f(320, 0);
	glEnd();

	glBegin(GL_LINES);
	glVertex2f(760, 1000);
	glVertex2f(760, 0);
	glEnd();

	glFlush();
}
void myinit()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glColor3f(0.0, 0.0, 1.0);
	glPointSize(2.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 1100.0, 0.0, 700.0);
}

int main(int argc, char** argv)
{
	int c_menu;
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1700, 800);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("TRANSMISI�N COMUNITARIA");
	glutDisplayFunc(display_about);
	glutIdleFunc(idle);
	glutKeyboardFunc(keyboardFunc);
	myinit();
	c_menu = glutCreateMenu(main_menu);
	glutAddMenuEntry("Aeroplane", 1);
	glutAddMenuEntry("Comet", 2);
	glutAddMenuEntry("Quit", 3);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutMainLoop();
	return 0;
}